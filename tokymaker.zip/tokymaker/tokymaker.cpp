
// ::::::::::::   ...      :::  .  .-:.     ::-.:::      :::.     :::::::.   .::::::.
// ;;;;;;;;''''.;;;;;;;.   ;;; .;;,.';;.   ;;;;';;;      ;;`;;     ;;;'';;' ;;;`    `
//      [[    ,[[     \[[, [[[[[/'    '[[,[[['  [[[     ,[[ '[[,   [[[__[[\.'[==/[[[[,
//      $$    $$$,     $$$_$$$$,        c$$"    $$'    c$$$cc$$$c  $$""""Y$$  '''    $
//      88,   "888,_ _,88P"888"88o,   ,8P"`    o88oo,.__888   888,_88o,,od8P 88b    dP
//      MMM     "YMMMMMP"  MMM "MMP" mM"       """"YUMMMYMM   ""` ""YUMMMP"   "YMmMY"

#include "tokymaker.h"





/***************Touch PAD*****************/

void TouchSensor::init(uint8_t pinNum_, const uint8_t *p_PinConfig_)
{
  uint8_t pin;

  // DBG_ASSERT(pinNum_ < NUM_TOUCH_MAX);
  // DBG_ASSERT(NULL != p_PinConfig_);

  pinNum = pinNum_;
  enable = false;


  for (uint8_t i = 0; i < pinNum; i++ )
    {
      pin = p_PinConfig_[i];

      PinManage[i].pin = pin;
      pinMode( pin, INPUT_PULLUP );

    }

}

void TouchSensor::add(uint8_t pin)
{
  if ( digitalPinToTouchChannel(pin) < 0)
  {
    return;
  }

  if ( pinNum >= NUM_TOUCH_MAX )
  {
    return;
  }

  for (uint8_t i = 0; i < pinNum; i++ )
  {
    if ( pin == PinManage[i].pin )
    {
      return;
    }
  }

  PinManage[pinNum].pin = pin;

  pinNum++;
}


void TouchSensor::start(uint8_t periodMs)
{
  uint8_t pin;


  samplePeriod = periodMs/SAMPLE_NORMAL_NUM;

  // DBG_ASSERT( samplePeriod >= 1 );


  for ( int i = 0; i < pinNum; i++ )
  {
    pin = PinManage[i].pin;
    PinManage[i].filterCnt = 0;

    PinValue[i] = touchRead(pin); 
    PinState[i] = STATE_RELEASE; 
    PinEvent[i] = EVENT_NULL; 
  }

  preMilliTime = millis() + (samplePeriod >> 2);  //balance the mcu

  enable = true;

}

void TouchSensor::stop()
{
  enable = false;
}


void TouchSensor::run()
{
  uint8_t now;

  if (!enable) return;

  now  = (uint8_t)millis();

  if ( (uint8_t)( now - preMilliTime) >= samplePeriod)
  {
    uint8_t currentValue;

    for ( int i = 0; i < pinNum; i++)
    {
      uint8_t pin = PinManage[i].pin;
      uint8_t &filterCnt = PinManage[i].filterCnt;

      uint8_t &lastValue = PinValue[i];

      currentValue = touchRead(pin);
      // ESP_LOGI(LOG_TAG_SEN, "Pad %d=%u, last=%u, ", i,  currentValue, lastValue );


      if ( currentValue > (lastValue + TOUCH_GAP) )
      {
        filterCnt++;
        if ( filterCnt >= SAMPLE_NORMAL_NUM )
        {
          lastValue = currentValue;

          PinState[i] = STATE_RELEASE; 

          filterCnt = 0;
        }
      }
      else if ( (currentValue + TOUCH_GAP) < lastValue )
      {
        filterCnt++;
        if ( filterCnt >= SAMPLE_NORMAL_NUM )
        {
          lastValue = currentValue;  

          if ( STATE_RELEASE == PinState[i] ) 
          {
            PinEvent[i] = EVENT_CLICK;            
          } 

          PinState[i] = STATE_PRESS; 

          filterCnt = 0;
        }
      }
      else
      {
        filterCnt = 0;        
      }


    }

    preMilliTime = now;
  }
}


uint8_t TouchSensor::getState(uint8_t pin)
{
  for ( int i = 0; i < pinNum; i++ )
  {
    if ( pin == PinManage[i].pin)
    {
      return PinState[i];
    }
  }

  return STATE_RELEASE;
}; 


uint8_t TouchSensor::getEvent(uint8_t pin)
{
  for ( int i = 0; i < pinNum; i++ )
  {
    if ( pin == PinManage[i].pin)
    {
      uint8_t event = PinEvent[i]; 
      PinEvent[i] = EVENT_NULL; 
      return event;
    }
  }

  return EVENT_NULL;
};




/***************RGB LED strip *****************/

void SerialRgb::add(uint8_t pin , uint32_t num, int type)
{
  uint8_t index;

  if ( !digitalPinCanOutput(pin) )
  {
    return;
  }

  if ( pinNum >= NUM_RGB_MAX )
  {
    Serial.println("Failed: Add up to 4 LED-strands");
    return;
  }

  index = pinNum;

  for (uint8_t i = 0; i < pinNum; i++ )
  {
    if ( pin == STRANDS[i].gpioNum )
    {
      index = i;
      break;
    }
  }

  STRANDS[index].gpioNum = pin;
  STRANDS[index].rmtChannel = index<<1;  //use even channel, it is not working when use odd channel,
  STRANDS[index].ledType = type;
  STRANDS[index].brightLimit = 32;
  STRANDS[index].numPixels = num;
  STRANDS[index].pixels = NULL;
  STRANDS[index]._stateVars = NULL;

  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);

  if (index == pinNum) pinNum++;  

}

void SerialRgb::init()
{
  digitalLeds_initDriver();
  for(int i = 0; i < pinNum; i++){
    pSrands[i] = &STRANDS[i];
  }
  if (digitalLeds_addStrands(pSrands, pinNum))
    Serial.println("Init RGB failed!");
}


void SerialRgb::write(uint8_t pin, uint16_t index, uint8_t red, uint8_t green, uint8_t blue)
{
  for ( int i = 0; i < pinNum; i++ )
  {
    if ( pin == STRANDS[i].gpioNum )
    {
      strand_t * pStrand = &STRANDS[i];
      pixelColor_t newColor = pixelFromRGB(red, green, blue);

      pStrand->pixels[index] = newColor;

      break;
    }
  }
}

void SerialRgb::update()
{
  digitalLeds_drawPixels(pSrands, pinNum);
}

