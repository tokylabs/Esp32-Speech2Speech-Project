#ifndef TOKYMAKDER_h
#define TOKYMAKDER_h

/** Arduino Settings
 * Board:  ESP32 Dev Moudule
 * Flash Mode: QIO
 * Flash Freq: 80MHz
 * Flash Size: 4MB
 */

#include "Arduino.h"
#include "esp32_digital_led_lib.h"

/*** ****/

/*** The VCC of OUT = 5.0V ***/
#define OUT1    23
#define OUT2    26  //DAC
#define OUT3    25  //DAC
#define OUT4    5  
#define OUT5    27  

/*** The VCC of IN = 3.3V ***/
#define IN1    34   //A1_6 , only input
#define IN2    33   //A1_5
#define IN3    32   //A1_4
#define IN4    39   //A1_0
#define IN5    35   //A1_7

/*** Touch Pads ***/
#define TOUCH1    12   //T5
#define TOUCH2    14   //T6
#define TOUCH3    13   //T4

/*** LEDs ***/
#define RGB_LED   18
#define LED_LEFT  4 
#define LED_RIGHT 15

/*** BUTTONs***/
#define BUTTON_A    36
#define BUTTON_B    2 



/*** SONAR HeadPort Pins(top view, Left to Right ): 5V 16 17 GND ***/
#define SONAR_D1 16
#define SONAR_D2 17

/*** OLED ***/
#define OLED_I2C_ADDR 0x3D
#define OLED_SCREEN_WIDTH 128
#define OLED_SCREEN_HEIGHT 64

#define OLED_RESET 19
#define OLED_SDA   21
#define OLED_SCL   22


/********* Touch Pads ********/
#define SAMPLE_NORMAL_NUM 2

#ifndef EVENT_NULL
#define EVENT_NULL  0   
#define EVENT_CLICK 1 
#endif

#ifndef STATE_PRESS
#define STATE_PRESS  0   
#define STATE_RELEASE  1   
#endif

#define NUM_TOUCH_MAX 3
#define TOUCH_GAP 3 //20


typedef struct {
    uint8_t pin;        //Arduino's pin
    uint8_t filterCnt;  //to filer
}PinManage_t;


class TouchSensor
{
public:
    TouchSensor(){ enable=false; pinNum=0;};

    void init(uint8_t pinNum_ = 0, const uint8_t *p_PinConfig_ = NULL);
    void add(uint8_t pin);
    void start(uint8_t periodMs);
    void run();
    void stop();
    uint8_t getState(uint8_t pin);
    uint8_t getEvent(uint8_t pin);

private:
    uint8_t pinNum;
    PinManage_t PinManage[NUM_TOUCH_MAX];
    uint8_t PinBaseValue[NUM_TOUCH_MAX];
    uint8_t PinValue[NUM_TOUCH_MAX];
    uint8_t PinState[NUM_TOUCH_MAX];
    uint8_t PinEvent[NUM_TOUCH_MAX];

    bool enable;

    uint8_t samplePeriod;
    uint8_t preMilliTime;

};


/********* RGB LED strip ********/

#define NUM_RGB_MAX 4    //LED limited by RMT resouce, it is not working when use odd channel,

class SerialRgb
{
public:
    SerialRgb(){pinNum=0;};

    void init();

    void add(uint8_t pin, uint32_t num, int type = LED_WS2812B_V3);
    void write(uint8_t pin, uint16_t index, uint8_t red, uint8_t green, uint8_t blue);
    void update();

private:
  uint8_t pinNum;
  bool instantUpdate;  //true=instant
  strand_t STRANDS[NUM_RGB_MAX];
  strand_t* pSrands[NUM_RGB_MAX];

};




#endif /* Pins_Arduino_h */
